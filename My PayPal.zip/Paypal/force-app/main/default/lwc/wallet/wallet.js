import { LightningElement, wire } from 'lwc';
import getWallet from '@salesforce/apex/WalletRecords.getWallet';
import wallet from '@salesforce/schema/wallet__c';
import addedfroms_Field from '@salesforce/schema/wallet__c.addedfroms__c';
import operations from '@salesforce/apex/WalletRecords.Operations';
import sendto_field from '@salesforce/schema/wallet__c.Send_To__c';
import sendMoney from '@salesforce/apex/WalletRecords.sendMoneyToPal';
import CurrentUserId from '@salesforce/user/Id';
import oneWallet from '@salesforce/apex/WalletRecords.getOneWallet';
import getProfile from '@salesforce/apex/profile.getProfile';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';


//const columns = [{label:'Name',fieldName:'Name',type:'Text'},
//{label:'Balance' ,fieldName:'balance__c', type:'Currency'},
//{label:'Added From' , fieldName:'addedfroms__c' , type:'Lookup(User)'}];

export default class Wallet extends LightningElement {
   currentuserWallet;
   currentProfile;
   currentUserId = CurrentUserId;
   sysAdmin;
   otherUser;
   selectedPal;
        add;
        showForm;
        sendMoneyForm;
        getsendAmount;
        wallets;
        walletId;
        objectApiName=wallet;
        fields = [addedfroms_Field];
        sendFormfields=[sendto_field];

userProfile(){
   getProfile().then(data=>{
      this.currentProfile=data;
      this.checkcurrentuser();
   }).catch(error=>{
      console.log(error);
   })
}
 //method to get the current profile
 //@wire(getProfile)
 //      pro({data,error}){
      //    if(data){
      //       this.currentProfile = data;
      //    }else if(error){
      //       console.log(error);
      //    }
      //  }

     
  //method to get one wallet
 // @wire(getOneWallet)
  //   one({data,error}){
   //   if(data){
   //      this.oneWallet=data;
    //  }else{
    //     console.log(error);
     // }
     //}
 
 

        getAmountValue(event){
        this.add = event.target.value;
        }


                                              //toasts for Add money

    ShowInsufficientBalanceEvent(){
      const event = new ShowToastEvent({
          title: 'Failed',
          message: 'Insufficent Balance In card',
          variant: 'error',
      });
      this.dispatchEvent(event);
  }

    ShowsuccessEvent(){
      const event = new ShowToastEvent({
          title: 'Toast message',
          message: 'Amount '+ this.add + ' Added Successfully',
          variant: 'success',
          mode: 'dismissable'
      });
      this.dispatchEvent(event);
  }
                            
                     //toats for SEnd Money

  ShowSendsuccessEvent(){
   const event = new ShowToastEvent({
       title: 'Toast message',
       message: 'Amount '+ this.getsendAmount+ ' sent Successfully',
       variant: 'success',
       mode: 'dismissable'
   });
   this.dispatchEvent(event);
}

ShowInsufficientBalanceToSendEvent(){
   const event = new ShowToastEvent({
       title: 'Failed',
       message: 'Insufficent Balance To Send',
       variant: 'error',
   });
   this.dispatchEvent(event);
}

                                            
    
         connectedCallback (){
            this.userProfile();   
         }


         //to get the current user wallet for template
          getCurrentUserWallet(){
             //one Wallet
          oneWallet({userId:this.currentUserId}).then(data=>{
            let temp = {...data}
            temp.recUrl = 'https://d5g00000fdfpaea5-dev-ed.lightning.force.com/lightning/r/wallet__c/' + data.Id + '/view';
            this.currentuserWallet=temp;
            this.otherUser=true;
            
          }).catch(error=>{
            console.log(error);
          })
          }
          

         //all wallets
           allWalletRecords(){
            
            getWallet().then(data=>{

               let tempData = [] ;
               data.forEach(d=>{
                   //for apeending the field in the client side to make the hyperlinks
               let tempCard = {} ;
               tempCard = {...d} ;
               tempCard.recUrl = 'https://d5g00000fdfpaea5-dev-ed.lightning.force.com/lightning/r/wallet__c/' + d.Id + '/view';
               tempData.push(tempCard) ;
       }) ;
   
               this.wallets = tempData ; 
              // this.wallets=data;
            }).catch(error=>{
               this.ShowInsufficientBalanceEvent();
            })
           }


           checkcurrentuser(){
               if(this.currentProfile=='System Administrator'){   
                  this.allWalletRecords();     
                  this.sysAdmin=true;

               }else{
                  this.getCurrentUserWallet();
                  
               }
           }


                                         //Add money Function
      addMoney(event){
        this.walletId = event.target.value;
        this.showForm =true;
        
      }

      handleSubmit(){
         this.showForm =false
         operations({walletId:this.walletId , addMoney:this.add}).then(data=>{
            if(data){
               this.ShowsuccessEvent()
               window.location.reload(); 
            }
           }).catch(error=>{
            console.log(error);
            this.ShowInsufficientBalanceEvent();
           });
         
      }

                                          //send Money
     sendMoney(event){
      this.sendMoneyForm = true;
      this.walletId = event.target.value;
      }
      getsendAmountValue(event){
       this.getsendAmount = event.target.value;
 
      }

     
      handleSend(event){
       this.selectedPal = event.detail.fields.Send_To__c;
         sendMoney({walletId:this.walletId , sendMoney:this.getsendAmount , palId:this.selectedPal }).then(data=>{
           if(data) {
            this.ShowSendsuccessEvent();
           this.sendMoneyForm = false;
             
           }
                  
         }).catch(error=>{
            this.ShowInsufficientBalanceToSendEvent();
            this.sendMoneyForm = false;
            console.log(error);
         });
         window.location.reload();
         
      }

                                      //to hide modal form

      hideForm(){
         this.showForm=false;
         this.sendMoneyForm = false;
      }

}