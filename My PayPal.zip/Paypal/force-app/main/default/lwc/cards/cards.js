import { LightningElement } from 'lwc';
import getAllCards from '@salesforce/apex/CardsClass.getAllCards';
import CARD_OBJECT from '@salesforce/schema/card__c' ;
import CARD_NAME from '@salesforce/schema/card__c.Name' ;
import CARD_NUMBER from '@salesforce/schema/card__c.card_no__c' ;
import CARD_CVV from '@salesforce/schema/card__c.cvv__c' ;
import CARD_USER from '@salesforce/schema/card__c.Name__c' ;
import CARD_AMOUNT from '@salesforce/schema/card__c.amount__c' ;
import CARD_EXPIRY from '@salesforce/schema/card__c.expiry_date__c'
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Cards extends LightningElement {

    cardfields=[CARD_NAME,CARD_NUMBER,CARD_CVV,CARD_EXPIRY,CARD_USER,CARD_AMOUNT];
    objectApiName = CARD_OBJECT;
    opennewcardform;
    allCardsData ;
    allCardsError ;


    newCardSuccess(){
        const event = new ShowToastEvent({
            title: 'Success',
            message: 'Card Added Successfully',
            variant: 'success',
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }
   

    connectedCallback(){
        this.allCards() ;
    }

    allCards(){
        getAllCards()
        .then(data=>{
            let tempData = [] ;
            data.forEach(card=>{
                //for apeending the field in the client side to make the hyperlinks
            let tempCard = {} ;
            tempCard = {...card} ;
            tempCard.recUrl = 'https://d5g00000fdfpaea5-dev-ed.lightning.force.com/lightning/r/card__c/' + card.Id +'/view' ;
            tempData.push(tempCard) ;
    }) ;

            this.allCardsData = tempData ; 
            console.log(this.allCardsData);
        })
        .catch(err=>{
            this.allCardsError = err ; 
            console.log(this.allCardsError);} ) ;
    }


    cardSubmit(){
        this.opennewcardform = false;

        window.location.reload();
       this.newCardSuccess()
    }
    hideForm(){
        this.opennewcardform=false;
    }
    createNewCard(){
        this.opennewcardform = true;
    }
    handleAddMoney(event){


    }
}