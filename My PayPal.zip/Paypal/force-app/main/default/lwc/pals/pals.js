import { LightningElement ,wire} from 'lwc';
import palrecords from '@salesforce/apex/Pals.palRecords';

export default class Pals extends LightningElement {

records;
@wire(palrecords) 
        rec({data,error}){
            if(data){
                let tempData = [] ;
                data.forEach(d=>{
                    //for appending the field in the client side to make the hyperlinks
                let tempCard = {} ;
                tempCard = {...d} ;
                tempCard.recUrl = 'https://d5g00000fcrt9eal-dev-ed.lightning.force.com/lightning/r/pals__c/' + d.Id +'/view' ;
                tempData.push(tempCard) ;
        }) ;
                this.records = tempData ; 
            }else{
                console.log(error);
            }
        }

}