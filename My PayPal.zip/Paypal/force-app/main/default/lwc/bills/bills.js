import { api, LightningElement ,wire } from 'lwc';
import getProfile from '@salesforce/apex/profile.getProfile';
import getbillRecords from '@salesforce/apex/BillsRecords.getbillRecords';
import checkClass from '@salesforce/apex/BillsRecords.check';
import billName from '@salesforce/schema/bills__c.Name';
import paid from '@salesforce/schema/bills__c.Paid__c';
import amount from '@salesforce/schema/bills__c.Amount__c';
import bills__c from '@salesforce/schema/bills__c';
import Walletused from '@salesforce/schema/bills__c.Pay_through_wallet__c';
import category from '@salesforce/schema/bills__c.category__c';
import forUser from '@salesforce/schema/bills__c.for_user__c';
import location from '@salesforce/schema/bills__c.location__c';
import payBefore from '@salesforce/schema/bills__c.pay_before__c';
import { deleteRecord } from 'lightning/uiRecordApi';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const actions = [
     { label: 'View', name: 'view'},
     { label: 'Edit', name: 'edit' },
     { label: 'Delete', name: 'delete' }
  ];
const cols=[
    {label:'Id', fieldName:'Id',type:'Id'},
    {label:'Name', fieldName:'recUrl',type:'url' , typeAttributes:{label:{fieldName:'Name'}}},
    {label:'Amount', fieldName:'amount__c', type:'currency'},
    {label:'Offer', fieldName:'offer_applied__c',type:'percent'}, 
    {label:'Paid Am.', fieldName:'Paid__c',type:'currency'},
    {label:'Pay Before', fieldName:'pay_before__c',type:'date'},
    { type: "button", typeAttributes: {  
        label: 'Pay',  
        name: 'Pay',  
        title: 'Pay',  
        disabled:{fieldName:'successful__c'},  
        value: 'send',  
        iconPosition: 'left'  } }  ,
    {type : 'action' , typeAttributes:{rowActions :actions ,menuAlignment: 'right'}}
] ;
const pageSize = 5 ;
export default class Passbook extends LightningElement { 
    opennewbillform;
    billfields =[billName,category,location,amount,paid,payBefore,forUser];
    showButton;
    action;
    editForm;
    deleteConfirm;
    toastError;
    viewForm;
    showForm;
    currentProfile;
    getbillRecords ;
    fields=[billName , paid , Walletused ];
    recId;
    objectApiName=bills__c;
    columns = cols;
    fullData ;
    startSize = 0 ;
    endSize = pageSize ;
    disablePrevious = false ;
    disableNext = false ;

    fullDataSize ;

@wire(getProfile) 
    profile({data , error}){
    if(data){
    if(data == 'System Administrator'){

        this.showButton = true;
        this.currentProfile = data;
      }else{
      this.showButton = false;
      }
    }
}


handlePrevious(){
    // this.disableNext = false ;
     if(this.startSize == pageSize){
         this.disablePrevious = true ;
     }
     else{
         this.disableNext = false ;
     }
     this.startSize = this.startSize - pageSize ;
     this.endSize = this.endSize - pageSize ;
     this.getbillRecords = this.fullData.slice(this.startSize, this.endSize) ;
 }

 handleNext(){
     this.disablePrevious = false ;
     if((this.fullDataSize - this.endSize) ===0){
        this.disableNext = true ;
        this.disablePrevious = false ;
    }
    else if(( this.fullDataSize- this.endSize) <= pageSize){
        this.disableNext = true ;
        this.disablePrevious = false ;
    }
     this.startSize = this.startSize + pageSize ;
     this.endSize = this.endSize + pageSize ;
     this.getbillRecords = this.fullData.slice(this.startSize, this.endSize) ;
 }


    //refreshData() {
    //   return refreshApex(this.getbillRecords);
    //}

    ShowInsufficientBalanceEvent(){
        const event = new ShowToastEvent({
            title: 'Failed',
            message: 'Insufficent Balance',
            variant: 'error',
        });
        this.dispatchEvent(event);
    }
    ShowsuccessEvent(){
        const event = new ShowToastEvent({
            title: 'Toast message',
            message: 'Bill Paid',
            variant: 'success',
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }

    connectedCallback(){
        this.allgetbillRecords() ;
    }
    allgetbillRecords(){
        getbillRecords().then(data=>{
            let tempData = [] ;
            data.forEach(d=>{
                //for apeending the field in the client side to make the hyperlinks
            let tempCard = {} ;
            tempCard = {...d} ;
            tempCard.recUrl = '/' + d.Id ;
            tempData.push(tempCard) ;
    }) ;

           // this.getbillRecords = tempData ; 
            
            this.fullData = tempData ;
            this.getbillRecords = tempData.slice(this.startSize, this.endSize);
            this.fullDataSize = this.fullData.length ;
            this.disablePrevious = true ;
        }).catch(err=>{
            alert(err);
           console.log(err);
        });
    }

callRowAction(event){
    this.recId =event.detail.row.Id; 
    
    this.action = event.detail.action.name; 
    if(this.action == 'Pay'){  
        this.showForm=true;      
    }
    else if(this.action=='view'){ 
     this.viewForm=true;
    }else if(this.action=='edit'){
        if(this.currentProfile=='System Administrator'){
            this.editForm=true;
            
        }else{
            const event = new ShowToastEvent({
                title: 'Failed',
                message: 'You Dont have permission to edit the form',
                variant: 'error',
            });
            this.dispatchEvent(event);
        }
    }else if(this.action=='delete'){
        if(this.currentProfile=='System Administrator'){
            console.log(this.recId);
            this.deleteConfirm = true;
        }else{
            const event = new ShowToastEvent({
                title: 'Failed',
                message: 'You Dont have permission to delete the form',
                variant: 'error',
            });
            this.dispatchEvent(event);

        }
        
    }
}

handleSubmit(event){
    ///this this if functiomn is getting called or not
     checkClass({billId:this.recId}).then(data=>{
        this.toastError=data;
        console.log(data)
        if(this.toastError){
            this.ShowsuccessEvent();   
        }
        
     }).catch(error=>{
        this.ShowInsufficientBalanceEvent();
        
     })
    this.showForm=false;  
    window.location.reload(); 
}
//create new bill function

createnewbill(){
    this.opennewbillform = true;
}
billSubmit(event){
    this.opennewbillform=false;
   window.location.reload(); 
}

//Update Bill

update(){
    this.editForm=false;
    const event = new ShowToastEvent({
        title: 'Success',
        message: 'Bill Updated Successfully',
        variant: 'success',
        mode: 'dismissable'
    });
    this.dispatchEvent(event);
    
    window.location.reload();
}

//delete Bill

deleterec(){
    deleteRecord(this.recId).then(data=>{
        window.location.reload();
        const event = new ShowToastEvent({
            title: 'Success',
            message: 'Bill Deleted',
            variant: 'success',
            mode: 'dismissable'
        });
        this.dispatchEvent(event);

        this.deleteConfirm=false;
        
        
    }).catch(error=>{
        console.log(error);
    })
}

hideForm(event){
    this.showForm=false;
    this.opennewbillform=false;
    this.viewForm=false;
    this.editForm = false;
    this.deleteConfirm=false;
}

}
