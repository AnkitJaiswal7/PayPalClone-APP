import { LightningElement, wire } from 'lwc';
import getRecords from '@salesforce/apex/PassbookClass.getRecords';
import sendEmail from'@salesforce/apex/Email.sendEmail';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';



const columns=[
    {label:'Id', fieldName:'Id',type:'Id'},
    {label:'Owner', fieldName:'recUrl',type:'url' , typeAttributes:{label:{fieldName:'Name'}}}, 
    {label:'Paid Amount', fieldName:'amount__c',type:'currency'},
    {label:'Vendor', fieldName:'vendor_name_c',type:'text'},
    {label:'Expense description', fieldName:'expense_description__c',type:'text'},
    { type: "button", typeAttributes: {  
        label: 'Send Record',  
        name: 'Send Record',  
        title: 'Send Record',  
        disabled:false,  
        value: 'send',  
        iconPosition: 'left'  } }
]
const pageSize = 5 ;
export default class Passbook extends LightningElement {
    columns = columns;
   details;
   recordId;
   fullData ;
   startSize = 0 ;
   endSize = pageSize ;
   disablePrevious = false ;
   disableNext = false ;

   fullDataSize ;



   handlePrevious(){
    // this.disableNext = false ;
     if(this.startSize == pageSize){
         this.disablePrevious = true ;
     }
     else{
         this.disableNext = false ;
     }
     this.startSize = this.startSize - pageSize ;
     this.endSize = this.endSize - pageSize ;
     this.details = this.fullData.slice(this.startSize, this.endSize) ;
 }

 handleNext(){
     this.disablePrevious = false ;
     if((this.fullDataSize - this.endSize) ===0){
        this.disableNext = true ;
        this.disablePrevious = false ;
    }
    else if(( this.fullDataSize- this.endSize) <= pageSize){
        this.disableNext = true ;
        this.disablePrevious = false ;
    }
     this.startSize = this.startSize + pageSize ;
     this.endSize = this.endSize + pageSize ;
     this.details = this.fullData.slice(this.startSize, this.endSize) ;
 }

   EmailEvent(){
    const event = new ShowToastEvent({
        title: 'Toast message',
        message: 'Record Sent on Your Mail',
        variant: 'success',
        mode: 'dismissable'
    });
    this.dispatchEvent(event);
}
    @wire(getRecords) 
               getRecord({data , error}){
                if(data){
                    let tempData = [] ;
            data.forEach(d=>{
                //for apeending the field in the client side to make the hyperlinks
            let tempCard = {} ;
            tempCard = {...d} ;
            tempCard.recUrl = '/' + d.Id ;
            tempData.push(tempCard) ;
    }) ;

           // this.details = tempData ; 
                    //this.details = data;
                    this.fullData = tempData ;
                    this.details = tempData.slice(this.startSize, this.endSize);
                    this.fullDataSize = this.fullData.length ;
                    this.disablePrevious = true ;
                    
                }
                else if(error){
                    console.log(error)
                    alert("Error");
                }
               }
     callRowAction(event){
        this.recordId = event.detail.row.Id;
    }
    @wire(sendEmail,{recordId:'$recordId'})
     rec({data , error}){
        if(data){
         this.EmailEvent();
        }else if(error){
            console.log(error);
        }
     };
       


}